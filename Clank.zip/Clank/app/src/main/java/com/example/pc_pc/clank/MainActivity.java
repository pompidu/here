package com.example.pc_pc.clank;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //Buttons
    Button cBagPlus, cBagMinus, cBootPlus, cBootMinus, cSwordplus, cSwordminus
            , cGoldPlus, cGoldMinus, cVictoryPlus, cVictoryMinus
                , cDragonPlus, cDragonMinus, cReset;

    //TextViews
    TextView cBag, cBoot, cSwords, cGold, cVictory, cDragon;

    //Counters
    int clank, boots, swords, gold, victory = 0;
    int dragon = 20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Clank In Bag - row 1
        cBagPlus=(Button) findViewById(R.id.buttonPlusRow1);
        cBag=(TextView) findViewById(R.id.textView2Row1);
        cBagPlus.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                clank++;
                cBag.setText(Integer.toString(clank));
            }
        });

        cBagMinus=(Button) findViewById(R.id.buttonMinusRow1);
        cBagMinus.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                if (clank < 1){
                    //Do nothing
                }else{
                    clank--;
                    cBag.setText(Integer.toString(clank));
                }
            }
        });

        //Boots in Deck - row 2
        cBootPlus=(Button) findViewById(R.id.buttonPlusRow2);
        cBoot=(TextView) findViewById(R.id.textView2Row2);
        cBootPlus.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                boots++;
                cBoot.setText(Integer.toString(boots));
            }
        });

        cBootMinus=(Button) findViewById(R.id.buttonMinusRow2);
        cBootMinus.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                if (boots < 1){
                    //Do nothing
                }else{
                    boots--;
                    cBoot.setText(Integer.toString(boots));
                }
            }
        });


        //Swords in Deck - row 3
        cSwordplus=(Button) findViewById(R.id.buttonPlusRow3);
        cSwords=(TextView) findViewById(R.id.textView2Row3);
        cSwordplus.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                swords++;
                cSwords.setText(Integer.toString(swords));
            }
        });

        cSwordminus=(Button) findViewById(R.id.buttonMinusRow3);
        cSwordminus.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                if (swords < 1){
                    //Do nothing
                }else{
                    swords--;
                    cSwords.setText(Integer.toString(swords));
                }
            }
        });

        //Gold - row 4
        cGoldPlus=(Button) findViewById(R.id.buttonPlusRow4);
        cGold=(TextView) findViewById(R.id.textView2Row4);
        cGoldPlus.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                gold++;
                cGold.setText(Integer.toString(gold));
            }
        });

        cGoldMinus=(Button) findViewById(R.id.buttonMinusRow4);
        cGoldMinus.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                if (gold < 1){
                    //Do nothing
                }else{
                    gold--;
                    cGold.setText(Integer.toString(gold));
                }
            }
        });

        //Victory Points - row 5
        cVictoryPlus=(Button) findViewById(R.id.buttonPlusRow5);
        cVictory=(TextView) findViewById(R.id.textView2Row5);
        cVictoryPlus.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                victory++;
                cVictory.setText(Integer.toString(victory));
            }
        });

        cVictoryMinus=(Button) findViewById(R.id.buttonMinusRow5);
        cVictoryMinus.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                if (victory < 1){
                    //Do nothing
                }else{
                    victory--;
                    cVictory.setText(Integer.toString(victory));
                }
            }
        });

        //Dragon - row 6
        cDragonPlus=(Button) findViewById(R.id.buttonPlusRow6);
        cDragon=(TextView) findViewById(R.id.textView2Row6);
        cDragonPlus.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                if (dragon < 20) {
                    dragon++;
                    cDragon.setText(Integer.toString(dragon));
                }
            }
        });

        cDragonMinus=(Button) findViewById(R.id.buttonMinusRow6);
        cDragonMinus.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                if (dragon < 1){
                    //Do nothing
                }else{
                    dragon--;
                    cDragon.setText(Integer.toString(dragon));
                }

            }
        });

        //Reset Button
        cReset=(Button) findViewById(R.id.reset);
        cReset.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                reset();
            }
        });
    }

    public void reset(){
        clank = boots = swords = gold = victory = 0;
        dragon = 20;
        cBag.setText(Integer.toString(clank));
        cBoot.setText(Integer.toString(boots));
        cSwords.setText(Integer.toString(swords));
        cGold.setText(Integer.toString(gold));
        cVictory.setText(Integer.toString(victory));
        cDragon.setText(Integer.toString(dragon));
    }

}
