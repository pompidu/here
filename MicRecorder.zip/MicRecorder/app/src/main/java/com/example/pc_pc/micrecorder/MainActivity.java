package com.example.pc_pc.micrecorder;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {

    private ProgressBar recordProgressBar;
    private Button  recordButton;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recordProgressBar = findViewById(R.id.progressRecord);
        recordButton = findViewById(R.id.holdToRecordButton);

        recordButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        recordProgressBar.setVisibility(View.VISIBLE);
                        return true;
                    case MotionEvent.ACTION_UP:
                        recordProgressBar.setVisibility(View.INVISIBLE);
                        return true;
                    case MotionEvent.ACTION_OUTSIDE:
                    recordProgressBar.setVisibility(View.INVISIBLE);
                    return true;
                    case MotionEvent.ACTION_CANCEL:
                        recordProgressBar.setVisibility(View.INVISIBLE);
                        return true;
                }
                return false;
            }
        });
    }
}
