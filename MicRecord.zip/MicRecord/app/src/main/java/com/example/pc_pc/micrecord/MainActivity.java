package com.example.pc_pc.micrecord;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {

    private ProgressBar recordBar;
    private Button recordButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Grab views by id
        recordBar = findViewById(R.id.recordProgress);
        recordButton = findViewById(R.id.record);

        //Set touch for hold to record
        recordButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event)
            {
                if (event.getAction() == MotionEvent.ACTION_DOWN)
                    recordBar.setVisibility(View.VISIBLE);
                if (event.getAction() == MotionEvent.ACTION_UP)
                    recordBar.setVisibility(View.INVISIBLE);
                //recordBar.setVisibility(View.VISIBLE);

                return true;
            }
        });

        }
}
